<?php
/**
 * Class Settings holds the upload settings
 *
 */
class Settings
{
    static $password = "passme";
    static $uploadFolder = "uploads/";
    static $uploadFolderNoscript = "../uploads/";
    static $fileManager = "filemanagenumber/";
    static $fileManagerNoscript = "../filemanagenumber/";
    static $privateFolder = "private/";
    static $privateFolderNoscript = "../private/";
}
?>
