<?php include("main.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16">
	<meta http-equiv="Content-Type" content="text/html; UTF-8" />
	<title>Evil Storage</title>
  <style type="text/css" media="all">
    @import url("style/dropZone.css");
    @import url("style/style.css");
  </style>
  <script type="text/javascript" src="js/jquery-latest.js"></script>
  <noscript>
		<meta http-equiv="refresh" content="0;url=noscript/noscript.html">
	</noscript>
</head>
<body>
  <div id="container">
  	<h1>Evil file storage</h1>
		<fieldset>
    	<legend>Add a new file to the storage</legend>
    	<form name="file-form" method="post" action="index.php" enctype="multipart/form-data">
      <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
      <div class="drop-zone">
				<figure class="upload-logo">
					<img src="/images/upload.png" class="upload-image"/>
					<figcaption class="drop-zone__prompt">Drop file here<br>or<br>click to upload</figcaption>
				</figure>
        <input type="file" name="file" id="file" class="drop-zone__input">
      </div>
      <p>
        <label for="postOption">Choose an option(<span title="Public: Choose public for a publicly viewable post &#013;Private: Choose private if you only want users with the link see your file" style="background-color:#FFFFFF;color:red;text-decoration:none">?</span>) to post file:</label>
        <select name="postOption" id="postOption">
          <option value="publicPost">public</option>
          <option value="privatePost">private</option>
        </select>
      </p>
			<p>
				<label for="password">Password for upload</label><br />
				<input type="password" name="password" id="password" />
			</p>
      <p>
        <input type="submit" name="submit" id="submit" value="Start upload" />
        <?php
          echo $message;
          echo $_GET['message'];
        ?>
      </p>
      </form>
    </fieldset>
    <fieldset>
      <legend>Previousely uploaded files</legend>
      <ul id="menu">
        <li><a href="">All files</a></li>
        <li><a href="">Documents</a></li>
        <li><a href="">Images</a></li>
        <li><a href="">Applications</a></li>
      </ul>
      <ul id="files">
        <?php echo $uploaded_files;?>
      </ul>
  	</fiealdset>
	</div>
  <script type="text/javascript" src="/js/dropZone.js"></script>
	<script src="js/filestorage.js"></script>
	<script type="text/javascript" src="js/formValidation.js"></script>
</body>
</html>
