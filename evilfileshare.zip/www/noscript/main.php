<?php
include("deletelinkgen.php");
//Load the settings
require_once("../settings.php");
//scrpt version of uplading folder
$uploadToFolder = Settings::$uploadFolderNoscript;
$message = "";
//Has the user uploaded something?
if(!isset($_FILES['file']) || $_FILES['file']['error'] == UPLOAD_ERR_NO_FILE)
{
    $message = "Error no file selected";
}
else
{
  if(isset($_FILES['file']))
  {
    $target_path = $uploadToFolder;
    $target_path = $target_path . time() . '_' . basename( $_FILES['file']['name']);
    //Check the password to verify legal upload
    if (empty($_POST['password']))
    {
      $message = "Input password to continue";
    }
    else
    {
      if($_POST['password'] != Settings::$password)
		  {
	  	  $message = "Invalid Password!";
        header('location:index.php?message='.$message);
      }
      else
      {
        //Try to move the uploaded file into the designated folder if they select private option
        if($_POST['postOption'] == "privatePost" )
        {
          $privateLink = get_Private_Link();
          $target_path = Settings::$privateFolderNoscript.$privateLink."/";
          $target_path_initial = $target_path;
          $target_path = $target_path . time() . '_' . basename( $_FILES['file']['name']);
          if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path))
          {
            $str = $target_path_initial;
            //remove first 3 "../" character from target_path
            $str = substr($str, 3);
            $deleteLink = get_Delete_Link($str);
            $message = "The file ".  basename( $_FILES['file']['name']).
            " has been uploaded";
            session_start();
            $_SESSION['target_path'] = substr($target_path, 3);
            $_SESSION['deletelink'] = $deleteLink;
            header('location:success.php');
          }
          else
          {
            $message = "There was an error uploading the file, please try again!";
            header('location:index.php?message='.$message);
          }
        }
        //Try to move the uploaded file into the designated folder if they select public option
        if ( $_POST['postOption'] == "publicPost" )
        {
          $target_path = Settings::$uploadFolderNoscript;
          $target_path = $target_path . time() . '_' . basename( $_FILES['file']['name']);
          if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path))
          {
            $str = $target_path;
            //remove first 3 "../" character from target_path
            $str = substr($str, 3);
            $deleteLink = get_Delete_Link($str);
            $message = "The file ".  basename( $_FILES['file']['name']).
            " has been uploaded";
            session_start();
            $_SESSION['target_path'] = substr($target_path, 3);
            $_SESSION['deletelink'] = $deleteLink;
            header('location:success.php');
          }
          else
          {
            $message = "There was an error uploading the file, please try again!";
            header('location:index.php?message='.$message);
          }
        }
      }
	  }
  }
}
//change $message display format if there is no files selected or no password input
if(strlen($message) > 0)
{
  $message = '<p class="error">' . $message . '</p>';
}
//if any other error than no file or no password then unset those 2 error message
if(strlen($_GET['message']) > 0)
{
  $message ="";
  $_GET['message'] = '<p class="error">' . $_GET['message'] . '</p>';
}
/** LIST UPLOADED FILES **/
$uploaded_files = "";

//Open directory for reading
$dh = opendir($uploadToFolder);

//LOOP through the files
while (($file = readdir($dh)) !== false)
{
	if($file != '.' && $file != '..')
	{
		$filename = $uploadToFolder . $file;
		$parts = explode("_", $file);
		$size = formatBytes(filesize($filename));
		$added = date("m/d/Y", $parts[0]);
		$origName = $parts[1];
		$filetype = getFileType(substr($file, strlen($file) - 3));
		$uploaded_files .= "<li class=\"$filetype\"><a href=\"$filename\">$origName</a> $size - $added</li>\n";
	}
}
closedir($dh);
if(strlen($uploaded_files) == 0)
{
	$uploaded_files = "<li><em>No files found</em></li>";
}
function getFileType($extension)
{
	$images = array('jpg', 'gif', 'png', 'bmp');
  $docs   = array('txt', 'rtf', 'doc');
  $apps   = array('zip', 'rar', 'exe');

  if(in_array($extension, $images)) return "Images";
	if(in_array($extension, $docs)) return "Documents";
  if(in_array($extension, $apps)) return "Applications";
  return "";
}
function formatBytes($bytes, $precision = 2)
{
  $units = array('B', 'KB', 'MB', 'GB', 'TB');

  $bytes = max($bytes, 0);
  $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
  $pow = min($pow, count($units) - 1);

	$bytes /= pow(1024, $pow);

  return round($bytes, $precision) . ' ' . $units[$pow];
}
?>
