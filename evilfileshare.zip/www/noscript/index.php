<?php include("main.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" href="../images/favicon.png" type="image/png" sizes="16x16">
<meta http-equiv="Content-Type" content="text/html; UTF-8" />
<title>Evil Storage</title>
	<style type="text/css" media="all">
   		@import url("../style/style.css");
	</style>
</head>
<body>
 	<div id="container">
   		 <h1>Evil file storage</h1>
			 <fieldset>
        <legend>Add a new file to the storage</legend>
        <form method="post" action="index.php" enctype="multipart/form-data">
       		<input type="hidden" name="MAX_FILE_SIZE" value="100000" />
        	<p>
 						<label for="name">Select file</label><br />
       			<input type="file" name="file" />
 					</p>
         	<p>
 						<label for="password">Password for upload</label><br />
       			<input type="password" name="password" />
 					</p>
 					<p>
 						<label for="postOption">Choose an option(<span title="Public: Choose public for a publicly viewable post &#013;Private: Choose private if you only want users with the link see your file" style="background-color:#FFFFFF;color:red;text-decoration:none">?</span>) to post file:</label>
 						<select name="postOption" id="pasteOption">
 							<option value="publicPost">public</option>
 							<option value="privatePost">private</option>
 						</select>
 					</p>
         	<p>
 						<input type="submit" name="submit" value="Start upload" />
            <?php
              echo $message;
              echo $_GET['message'];
            ?>
 					</p>
      	</form>
 			</fieldset>
			<fieldset>
      	<legend>Previousely uploaded files</legend>
				<ul id="menu">
					<li>All files</li>
				</ul>
				<ul id="files">
					<?php echo $uploaded_files; ?>
				</ul>
      </fiealdset>
	</div>
</body>
</html>
