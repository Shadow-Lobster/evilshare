<?php
	include("geturl.php");
	session_start();
	$filelink = get_Server_Url()."/".$_SESSION['target_path'];
	$deleteLink = get_Server_Url()."/delete.php?delete=".$_SESSION['deletelink'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link rel="icon" href="../images/favicon.png" type="image/png" sizes="16x16">
		<title> Files Uploaded Successfully </title>
		<style type="text/css" media="all">
				@import url("../style/successNoscript.css");
		</style>
	</head>
	<body>
		<div class="container">
			<h1 class="successHead">
	 			Your file are uploaded successfully.
	 		</h1>
    	<p class="links">Links to share and delete file</p>
			<center>
				<p>
					<input type="text" id="filelink" name="filelink" value="<?php echo $filelink?>" readonly>
				</p>
				<p>
					<input type="text" id="deletelink" name="deletelink" value="<?php echo $deleteLink?>" readonly>
				</p>
			</center>
		</div>
	</body>
</html>
