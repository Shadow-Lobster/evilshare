<?php
require_once("settings.php");
//randomString function
function generate_Random_String($length)
{
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++)
  {
     $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}
function get_Delete_Link($target_path)
{
  for ($i = 2; $i > 1; $i++)
  {
    $randomString = generate_Random_String(10);
    if (!file_exists(Settings::$fileManager.$randomString))
    {
      $manageLink = Settings::$fileManager . $randomString;
      $fileCreate= fopen($manageLink, 'w') or die("There was an error in changing your title.  <br />");
      fwrite($fileCreate, $target_path);
      fclose($fileCreate);
      $i = -1;
    }
  }
  return $randomString;
}
function get_Private_Link()
{
  for ( $i = 2; $i > 1; $i++)
  {
    $randomString = generate_Random_String(5);
    if (!is_dir(Settings::$privateFolder.$randomString))
    {
      $viewLink = Settings::$privateFolder.$randomString;
      mkdir($viewLink, 0777);
      $i = -1;
    }
  }
  return $randomString;
}
?>
