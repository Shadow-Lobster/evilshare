<?php
require_once("settings.php");
$randomId = $_GET['delete'];
$fileLocation = Settings::$fileManager.$randomId;
$deleteLocation = file_get_contents($fileLocation);
$check = file_exists($deleteLocation);
if(is_dir($deleteLocation))
{
  $files = glob($deleteLocation.'*');
  // Deleting all the files in the list
  foreach($files as $file)
  {
    if(is_file($file))
    // Delete the given file
      unlink($file);
  }
  rmdir($deleteLocation);
  unlink($fileLocation);
  $title = "Deletion Complete";
}
if(file_exists($deleteLocation))
{
  unlink($deleteLocation);
  unlink($fileLocation);
  $title = "Deletion Complete";
}
else
{
  if( !file_exists($deleteLocation) || !file_exists($fileLocation))
  {
    $title = "File doesn't exist";
  }
}
//echo '<a href="unlink.php?delete=.>
?>
<html>
  <head>
    <title><?php $title; ?></title>
  </head>
  <body>
    <?php
      echo $randomId;
    ?>
    <br/>
    <?php
      echo $deleteLocation;
    ?>
    <br/>
    <?php
      echo $check
    ?>
  </body>
</html>
