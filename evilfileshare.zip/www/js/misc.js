function copyToClipboard(element)
{
  var copyText = document.getElementById(element);
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
}
