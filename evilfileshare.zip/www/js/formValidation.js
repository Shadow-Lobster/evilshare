document.getElementById("submit").onclick = function(e) {
  if (document.getElementById("file").value == "")
  {
    e.preventDefault();
    alert("Please select a file.");
  }
  if (document.getElementById("password").value == "")
  {
    e.preventDefault();
    alert("Please input a password.");
  }
}
